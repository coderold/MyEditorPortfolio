import { useState, useEffect } from 'react'

/* ─────────────────────────────────────────────────────────────────────────────
   DATA
───────────────────────────────────────────────────────────────────────────── */

const PROJECTS = [
  {
    id: 1,
    title: 'Horizon — Brand Film',
    category: 'Commercial',
    desc: 'Full narrative commercial for a luxury outdoor apparel brand. Cut to build tension and release across 90 seconds of precise storytelling.',
    tools: ['Premiere Pro', 'After Effects'],
    photo: '1536240478700-b869ad10a2eb',
  },
  {
    id: 2,
    title: 'The Quiet Hours',
    category: 'Cinematic Essay',
    desc: 'A documentary essay on solitude in modern cities. Desaturated palette, handheld texture, and a jazz-inflected sound design.',
    tools: ['DaVinci Resolve', 'Premiere Pro'],
    photo: '1489599849927-2ee91cede3ba',
  },
  {
    id: 3,
    title: 'Pulse — Gym Launch',
    category: 'Social Media',
    desc: 'Fast-cut 30-second reel for a fitness brand launch. Beat-sync editing, kinetic typography, and bold motion graphics.',
    tools: ['Premiere Pro', 'After Effects'],
    photo: '1574717024653-61fd2cf4d44d',
  },
  {
    id: 4,
    title: 'Velvet & Steel',
    category: 'Fashion Film',
    desc: 'Editorial fashion film for an independent designer. Slow-motion sequences intercut with abstract macro texture inserts.',
    tools: ['DaVinci Resolve', 'Premiere Pro'],
    photo: '1558618666-fcd25c85cd64',
  },
  {
    id: 5,
    title: 'Echo Chamber',
    category: 'Music Video',
    desc: 'Concept music video for an indie electronic artist. Glitch compositing, analog overlays, and split-frame architecture.',
    tools: ['After Effects', 'Premiere Pro'],
    photo: '1511671001595-f2e4d7d19e12',
  },
  {
    id: 6,
    title: 'Meridian — Tech Launch',
    category: 'Product Film',
    desc: 'Precision product reveal for a consumer electronics launch. 3D motion graphics, clean transitions, and broadcast delivery.',
    tools: ['After Effects', 'Premiere Pro', 'Cinema 4D'],
    photo: '1611532736597-de2d4265fba3',
  },
]

const SOCIALS = [
  {
    label: 'YouTube',
    handle: '@jeffmolina',
    icon: (
      <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
        <path d="M22.54 6.42a2.78 2.78 0 0 0-1.95-1.96C18.88 4 12 4 12 4s-6.88 0-8.59.46a2.78 2.78 0 0 0-1.95 1.96A29 29 0 0 0 1 12a29 29 0 0 0 .46 5.58 2.78 2.78 0 0 0 1.95 1.96C5.12 20 12 20 12 20s6.88 0 8.59-.46a2.78 2.78 0 0 0 1.95-1.96A29 29 0 0 0 23 12a29 29 0 0 0-.46-5.58zM9.75 15.02V8.98L15.5 12l-5.75 3.02z" />
      </svg>
    ),
  },
  {
    label: 'Vimeo',
    handle: 'vimeo.com/jeffmolina',
    icon: (
      <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
        <path d="M23.977 6.416c-.105 2.338-1.739 5.543-4.894 9.609-3.268 4.247-6.026 6.37-8.29 6.37-1.409 0-2.578-1.294-3.553-3.881L5.322 12.5c-.89-3.587-1.844-5.381-2.88-5.381-.225 0-1.012.474-2.357 1.416L0 7.288c1.482-1.299 2.944-2.598 4.382-3.895 1.977-1.706 3.461-2.605 4.462-2.696 2.34-.225 3.779 1.372 4.314 4.793.579 3.669 1.005 5.952 1.274 6.853.704 3.194 1.48 4.791 2.333 4.791.661 0 1.653-.829 2.973-2.485 1.32-1.657 2.024-2.914 2.111-3.775.188-1.43-.413-2.148-1.797-2.148-.64 0-1.302.147-1.986.44 1.317-4.318 3.842-6.424 7.571-6.309z" />
      </svg>
    ),
  },
  {
    label: 'LinkedIn',
    handle: 'linkedin.com/in/jeffmolina',
    icon: (
      <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
        <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6zM2 9h4v12H2z" />
        <circle cx="4" cy="4" r="2" />
      </svg>
    ),
  },
  {
    label: 'Instagram',
    handle: '@jeffmolina.edit',
    icon: (
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <rect x="2" y="2" width="20" height="20" rx="5" ry="5" />
        <circle cx="12" cy="12" r="4" />
        <circle cx="17.5" cy="6.5" r="0.5" fill="currentColor" />
      </svg>
    ),
  },
  {
    label: 'X / Twitter',
    handle: '@jeffmolina_',
    icon: (
      <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
        <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-4.714-6.231-5.401 6.231H2.746l7.73-8.835L1.254 2.25H8.08l4.253 5.622zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
      </svg>
    ),
  },
]

const TICKER_ITEMS = [
  'VIDEO EDITING', 'COLOR GRADING', 'MOTION GRAPHICS', 'SOUND DESIGN',
  'PREMIERE PRO', 'DAVINCI RESOLVE', 'AFTER EFFECTS', 'CINEMA 4D',
  'NARRATIVE EDITING', 'BRAND FILMS', 'SOCIAL CONTENT', 'FASHION FILMS',
]

/* ─────────────────────────────────────────────────────────────────────────────
   ICON PRIMITIVES
───────────────────────────────────────────────────────────────────────────── */

const IconSun = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="12" cy="12" r="4" />
    <line x1="12" y1="2" x2="12" y2="5" /><line x1="12" y1="19" x2="12" y2="22" />
    <line x1="4.22" y1="4.22" x2="6.34" y2="6.34" /><line x1="17.66" y1="17.66" x2="19.78" y2="19.78" />
    <line x1="2" y1="12" x2="5" y2="12" /><line x1="19" y1="12" x2="22" y2="12" />
    <line x1="4.22" y1="19.78" x2="6.34" y2="17.66" /><line x1="17.66" y1="6.34" x2="19.78" y2="4.22" />
  </svg>
)

const IconMoon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" />
  </svg>
)

const IconPlay = () => (
  <svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor">
    <path d="M6 3.7l14.4 8.3L6 20.3V3.7z" />
  </svg>
)

const IconArrow = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
    <line x1="5" y1="12" x2="19" y2="12" /><polyline points="12 5 19 12 12 19" />
  </svg>
)

const IconExternal = () => (
  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <line x1="7" y1="17" x2="17" y2="7" /><polyline points="7 7 17 7 17 17" />
  </svg>
)

/* ─────────────────────────────────────────────────────────────────────────────
   SHARED STYLE HELPERS
───────────────────────────────────────────────────────────────────────────── */

const S = {
  overline: {
    display: 'flex' as const,
    alignItems: 'center' as const,
    gap: 12,
    marginBottom: 24,
  },
  overlineBar: {
    width: 32,
    height: 2,
    background: 'var(--accent)',
    flexShrink: 0,
  },
  overlineText: {
    fontSize: 10,
    fontWeight: 700,
    letterSpacing: '0.22em',
    textTransform: 'uppercase' as const,
    color: 'var(--accent)',
  },
  container: {
    maxWidth: 1440,
    margin: '0 auto',
    width: '100%',
  },
}

/* ─────────────────────────────────────────────────────────────────────────────
   NAV
───────────────────────────────────────────────────────────────────────────── */

function Nav({ dark, toggle }: { dark: boolean; toggle: () => void }) {
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const fn = () => setScrolled(window.scrollY > 32)
    window.addEventListener('scroll', fn, { passive: true })
    return () => window.removeEventListener('scroll', fn)
  }, [])

  return (
    <header
      style={{
        position: 'fixed',
        inset: '0 0 auto 0',
        zIndex: 200,
        background: scrolled ? 'var(--nav-blur)' : 'transparent',
        backdropFilter: scrolled ? 'blur(16px) saturate(180%)' : 'none',
        WebkitBackdropFilter: scrolled ? 'blur(16px) saturate(180%)' : 'none',
        borderBottom: scrolled ? '1px solid var(--border)' : '1px solid transparent',
        transition: 'background 0.4s ease, border-color 0.4s ease',
      }}
    >
      <div
        className="nav-wrap"
        style={{
          ...S.container,
          height: 72,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          padding: '0 48px',
        }}
      >
        {/* Logo */}
        <a href="#top" style={{ textDecoration: 'none', display: 'flex', alignItems: 'baseline', gap: 1 }}>
          <span
            className="font-display"
            style={{ fontSize: 20, fontWeight: 900, letterSpacing: '0.06em', color: 'var(--text)' }}
          >
            JMM
          </span>
          <span style={{ fontSize: 24, fontWeight: 900, color: 'var(--accent)', lineHeight: 1 }}>.</span>
        </a>

        {/* Links + toggle */}
        <div className="nav-links" style={{ display: 'flex', alignItems: 'center', gap: 40 }}>
          {['Works', 'About', 'Contact'].map((lnk) => (
            <NavLink key={lnk} href={`#${lnk.toLowerCase()}`} label={lnk} />
          ))}
          <ThemeToggle dark={dark} toggle={toggle} compact />
        </div>
      </div>
    </header>
  )
}

function NavLink({ href, label }: { href: string; label: string }) {
  const [hov, setHov] = useState(false)
  return (
    <a
      href={href}
      onMouseEnter={() => setHov(true)}
      onMouseLeave={() => setHov(false)}
      style={{
        textDecoration: 'none',
        fontSize: 12,
        fontWeight: 600,
        letterSpacing: '0.14em',
        textTransform: 'uppercase',
        color: hov ? 'var(--text)' : 'var(--muted)',
        transition: 'color 0.2s ease',
      }}
    >
      {label}
    </a>
  )
}

function ThemeToggle({ dark, toggle, compact }: { dark: boolean; toggle: () => void; compact?: boolean }) {
  const [hov, setHov] = useState(false)
  return (
    <button
      onClick={toggle}
      onMouseEnter={() => setHov(true)}
      onMouseLeave={() => setHov(false)}
      aria-label={dark ? 'Switch to light mode' : 'Switch to dark mode'}
      style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        width: compact ? 38 : 48,
        height: compact ? 38 : 48,
        borderRadius: compact ? 8 : 12,
        background: hov ? 'var(--accent-dim)' : 'var(--card)',
        border: `1px solid ${hov ? 'var(--accent)' : 'var(--border)'}`,
        color: hov ? 'var(--accent)' : 'var(--muted)',
        cursor: 'pointer',
        transition: 'all 0.22s ease',
        flexShrink: 0,
      }}
    >
      {dark ? <IconSun /> : <IconMoon />}
    </button>
  )
}

/* ─────────────────────────────────────────────────────────────────────────────
   HERO
───────────────────────────────────────────────────────────────────────────── */

function Hero() {
  const [loaded, setLoaded] = useState(false)

  return (
    <section
      id="top"
      className="hero-section"
      style={{
        minHeight: '100svh',
        background: 'var(--bg)',
        position: 'relative',
        overflow: 'hidden',
        display: 'flex',
        alignItems: 'center',
        padding: '112px 48px 80px',
      }}
    >
      {/* Portrait bled into the background — absolutely positioned, right half */}
      <div
        aria-hidden={!loaded}
        style={{
          position: 'absolute',
          top: 0,
          right: 0,
          width: '52%',
          height: '100%',
          pointerEvents: 'none',
        }}
      >
        <img
          src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=900&h=1100&fit=crop&crop=face&auto=format"
          alt="Jeff Matthew Molina"
          onLoad={() => setLoaded(true)}
          style={{
            width: '100%',
            height: '100%',
            objectFit: 'cover',
            objectPosition: 'center top',
            opacity: loaded ? 1 : 0,
            transition: 'opacity 0.8s ease',
            display: 'block',
          }}
        />
        {/* Left-side fade — blends photo into page background */}
        <div
          aria-hidden
          style={{
            position: 'absolute',
            inset: 0,
            background: 'linear-gradient(to right, var(--bg) 0%, var(--bg) 8%, transparent 42%)',
          }}
        />
        {/* Top fade */}
        <div
          aria-hidden
          style={{
            position: 'absolute',
            inset: 0,
            background: 'linear-gradient(to bottom, var(--bg) 0%, transparent 18%, transparent 72%, var(--bg) 100%)',
          }}
        />
        {/* Subtle dark tint over the photo for contrast */}
        <div
          aria-hidden
          style={{
            position: 'absolute',
            inset: 0,
            background: 'rgba(0,0,0,0.18)',
          }}
        />
      </div>

      {/* Content — sits on top of the blended photo */}
      <div
        className="hero-grid"
        style={{
          ...S.container,
          display: 'grid',
          gridTemplateColumns: '1fr 1fr',
          gap: 64,
          alignItems: 'center',
          position: 'relative',
          zIndex: 1,
        }}
      >
        {/* ── Left: Text ── */}
        <div className="hero-text" style={{ paddingTop: 32 }}>
          {/* Overline */}
          <div style={S.overline}>
            <div style={S.overlineBar} />
            <span style={S.overlineText}>Video Editor & Visual Storyteller</span>
          </div>

          {/* Main headline — stacked with outline/fill alternation */}
          <h1
            className="font-display hero-headline"
            style={{
              fontSize: 'clamp(60px, 6.8vw, 104px)',
              fontWeight: 900,
              lineHeight: 0.9,
              letterSpacing: '-0.025em',
              marginBottom: 36,
              color: 'var(--text)',
            }}
          >
            <span style={{ display: 'block' }}>JEFF</span>
            <span
              style={{
                display: 'block',
                WebkitTextStroke: '2px var(--text)',
                color: 'transparent',
              }}
            >
              MATTHEW
            </span>
            <span style={{ display: 'block' }}>MOLINA</span>
          </h1>

          {/* Tagline */}
          <p
            style={{
              fontSize: 17,
              lineHeight: 1.75,
              color: 'var(--muted)',
              maxWidth: 400,
              marginBottom: 48,
              fontWeight: 300,
            }}
          >
            Crafting visual stories through high-impact, rhythmic video editing.
            Every frame is intentional — every cut tells the story.
          </p>

          {/* CTAs */}
          <div className="hero-cta-row" style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
            <BtnPrimary href="#works" label="View Works" icon={<IconArrow />} />
            <BtnOutline href="#contact" label="Let's Talk" />
          </div>
        </div>

        {/* Right column intentionally empty — portrait fills it via absolute positioning */}
        <div className="hero-frame" />
      </div>
    </section>
  )
}

/* ── Button primitives ────────────────────────────────────────────────────── */

function BtnPrimary({ href, label, icon }: { href: string; label: string; icon?: React.ReactNode }) {
  const [hov, setHov] = useState(false)
  return (
    <a
      href={href}
      onMouseEnter={() => setHov(true)}
      onMouseLeave={() => setHov(false)}
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: 10,
        padding: '14px 28px',
        background: 'var(--accent)',
        color: '#fff',
        borderRadius: 4,
        fontSize: 12,
        fontWeight: 700,
        letterSpacing: '0.12em',
        textTransform: 'uppercase',
        textDecoration: 'none',
        transition: 'transform 0.22s ease, box-shadow 0.22s ease',
        transform: hov ? 'translateY(-2px)' : 'none',
        boxShadow: hov ? '0 12px 36px var(--accent-glow)' : '0 4px 16px var(--accent-dim)',
        whiteSpace: 'nowrap',
      }}
    >
      {label}
      {icon}
    </a>
  )
}

function BtnOutline({ href, label }: { href: string; label: string }) {
  const [hov, setHov] = useState(false)
  return (
    <a
      href={href}
      onMouseEnter={() => setHov(true)}
      onMouseLeave={() => setHov(false)}
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: 8,
        padding: '14px 28px',
        background: 'transparent',
        color: 'var(--text)',
        border: `1px solid ${hov ? 'var(--text)' : 'var(--border)'}`,
        borderRadius: 4,
        fontSize: 12,
        fontWeight: 600,
        letterSpacing: '0.12em',
        textTransform: 'uppercase',
        textDecoration: 'none',
        transition: 'border-color 0.2s ease',
        whiteSpace: 'nowrap',
      }}
    >
      {label}
    </a>
  )
}

/* ─────────────────────────────────────────────────────────────────────────────
   TICKER STRIP
───────────────────────────────────────────────────────────────────────────── */

function Ticker() {
  const doubled = [...TICKER_ITEMS, ...TICKER_ITEMS]
  return (
    <div
      style={{
        background: 'var(--accent)',
        overflow: 'hidden',
        padding: '14px 0',
        userSelect: 'none',
      }}
    >
      <div className="ticker-track">
        {doubled.map((item, i) => (
          <span
            key={i}
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: 24,
              paddingRight: 48,
              whiteSpace: 'nowrap',
              fontSize: 11,
              fontWeight: 800,
              letterSpacing: '0.2em',
              textTransform: 'uppercase',
              color: '#fff',
            }}
          >
            {item}
            <span style={{ width: 4, height: 4, borderRadius: '50%', background: 'rgba(255,255,255,0.5)', flexShrink: 0 }} />
          </span>
        ))}
      </div>
    </div>
  )
}

/* ─────────────────────────────────────────────────────────────────────────────
   WORKS SECTION
───────────────────────────────────────────────────────────────────────────── */

function Works() {
  return (
    <section
      id="works"
      className="works-section"
      style={{ background: 'var(--bg2)', padding: '112px 48px' }}
    >
      <div style={S.container}>
        {/* Header */}
        <div
          style={{
            display: 'flex',
            alignItems: 'flex-end',
            justifyContent: 'space-between',
            marginBottom: 56,
            gap: 24,
            flexWrap: 'wrap',
          }}
        >
          <div>
            <div style={S.overline}>
              <div style={S.overlineBar} />
              <span style={S.overlineText}>Selected Work</span>
            </div>
            <h2
              className="font-display"
              style={{
                fontSize: 'clamp(40px, 5vw, 72px)',
                fontWeight: 900,
                letterSpacing: '-0.025em',
                lineHeight: 0.95,
                color: 'var(--text)',
              }}
            >
              THE REEL
            </h2>
          </div>
          <p
            style={{
              maxWidth: 340,
              fontSize: 14,
              lineHeight: 1.75,
              color: 'var(--muted)',
            }}
          >
            A curated selection spanning commercial, narrative, and digital work.
            Each project is a story told through careful cuts, color, and rhythm.
          </p>
        </div>

        {/* Grid */}
        <div
          className="works-grid"
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(3, 1fr)',
            gap: 24,
          }}
        >
          {PROJECTS.map((p) => (
            <VideoCard key={p.id} project={p} />
          ))}
        </div>
      </div>
    </section>
  )
}

function VideoCard({ project }: { project: typeof PROJECTS[number] }) {
  const [hov, setHov] = useState(false)
  const [loaded, setLoaded] = useState(false)

  return (
    <article
      onMouseEnter={() => setHov(true)}
      onMouseLeave={() => setHov(false)}
      style={{
        background: 'var(--card)',
        border: `1px solid ${hov ? 'var(--accent)' : 'var(--border)'}`,
        borderRadius: 6,
        overflow: 'hidden',
        cursor: 'pointer',
        transition: 'transform 0.3s ease, box-shadow 0.3s ease, border-color 0.25s ease',
        transform: hov ? 'translateY(-5px)' : 'none',
        boxShadow: hov ? 'var(--shadow-lift)' : 'var(--shadow-card)',
      }}
    >
      {/* Thumbnail */}
      <div
        style={{
          position: 'relative',
          width: '100%',
          aspectRatio: '16/9',
          background: '#080808',
          overflow: 'hidden',
        }}
      >
        <img
          src={`https://images.unsplash.com/photo-${project.photo}?w=640&h=360&fit=crop&auto=format`}
          alt={project.title}
          loading="lazy"
          onLoad={() => setLoaded(true)}
          style={{
            width: '100%',
            height: '100%',
            objectFit: 'cover',
            display: 'block',
            opacity: loaded ? (hov ? 0.55 : 0.78) : 0,
            transform: hov ? 'scale(1.05)' : 'scale(1)',
            transition: 'opacity 0.35s ease, transform 0.55s ease',
          }}
        />

        {/* Gradient */}
        <div
          aria-hidden
          style={{
            position: 'absolute',
            inset: 0,
            background: 'linear-gradient(to bottom, transparent 35%, rgba(0,0,0,0.65) 100%)',
            pointerEvents: 'none',
          }}
        />

        {/* Category badge */}
        <div
          style={{
            position: 'absolute',
            top: 12,
            left: 12,
            padding: '4px 10px',
            background: 'rgba(0,0,0,0.55)',
            backdropFilter: 'blur(6px)',
            WebkitBackdropFilter: 'blur(6px)',
            border: '1px solid rgba(255,255,255,0.1)',
            borderRadius: 3,
            fontSize: 9,
            fontWeight: 700,
            letterSpacing: '0.16em',
            textTransform: 'uppercase',
            color: 'rgba(255,255,255,0.65)',
          }}
        >
          {project.category}
        </div>

        {/* Play button */}
        <div
          style={{
            position: 'absolute',
            top: '50%',
            left: '50%',
            transform: `translate(-50%, -50%) scale(${hov ? 1 : 0.8})`,
            width: 52,
            height: 52,
            borderRadius: '50%',
            background: hov ? 'var(--accent)' : 'rgba(255,255,255,0.12)',
            backdropFilter: 'blur(6px)',
            WebkitBackdropFilter: 'blur(6px)',
            border: `2px solid ${hov ? 'var(--accent)' : 'rgba(255,255,255,0.25)'}`,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: '#fff',
            transition: 'all 0.3s ease',
            boxShadow: hov ? '0 0 32px var(--accent-glow)' : 'none',
          }}
        >
          <IconPlay />
        </div>
      </div>

      {/* Body */}
      <div style={{ padding: '20px 22px 24px' }}>
        <h3
          className="font-display"
          style={{
            fontSize: 17,
            fontWeight: 800,
            letterSpacing: '-0.01em',
            lineHeight: 1.3,
            color: 'var(--text)',
            marginBottom: 8,
          }}
        >
          {project.title}
        </h3>
        <p
          style={{
            fontSize: 13,
            lineHeight: 1.7,
            color: 'var(--muted)',
            marginBottom: 16,
          }}
        >
          {project.desc}
        </p>
        {/* Tool tags */}
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
          {project.tools.map((t) => (
            <span
              key={t}
              style={{
                padding: '3px 10px',
                background: 'var(--accent-dim)',
                border: '1px solid rgba(255,62,62,0.18)',
                borderRadius: 3,
                fontSize: 10,
                fontWeight: 600,
                letterSpacing: '0.06em',
                color: 'var(--accent)',
              }}
            >
              {t}
            </span>
          ))}
        </div>
      </div>
    </article>
  )
}

/* ─────────────────────────────────────────────────────────────────────────────
   ABOUT + CONTACT
───────────────────────────────────────────────────────────────────────────── */

function AboutContact() {
  const [copied, setCopied] = useState(false)
  const copy = () => {
    navigator.clipboard.writeText('hello@jeffmolina.com').catch(() => {})
    setCopied(true)
    setTimeout(() => setCopied(false), 2200)
  }

  return (
    <section
      id="about"
      className="about-section"
      style={{ background: 'var(--bg)', padding: '112px 48px' }}
    >
      <div
        className="about-grid"
        style={{
          ...S.container,
          display: 'grid',
          gridTemplateColumns: '1fr 1fr',
          gap: 88,
          alignItems: 'start',
        }}
      >
        {/* ── Left: About ── */}
        <div>
          <div style={S.overline}>
            <div style={S.overlineBar} />
            <span style={S.overlineText}>About Me</span>
          </div>

          <h2
            className="font-display"
            style={{
              fontSize: 'clamp(36px, 4vw, 60px)',
              fontWeight: 900,
              lineHeight: 1.0,
              letterSpacing: '-0.025em',
              color: 'var(--text)',
              marginBottom: 36,
            }}
          >
            Editing is not<br />
            <span
              style={{
                WebkitTextStroke: '1.5px var(--text)',
                color: 'transparent',
              }}
            >
              assembly.
            </span>
          </h2>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
            {[
              "I'm Jeff — a Manila-raised, globally-working video editor obsessed with the invisible architecture of a great cut. For over 8 years I've helped brands, creators, and filmmakers turn raw footage into work that makes people feel something.",
              "My editorial philosophy centers on rhythm and intention. I don't cut to fill time — I cut to direct attention. Whether it's a 15-second social clip or a 10-minute documentary, every element is in service of the story.",
              "I deliver fast without sacrificing craft. Premiere Pro, DaVinci Resolve, and After Effects are my primary tools. I'm comfortable with everything from offline assembly to color-graded, sound-designed final deliverables.",
            ].map((text, i) => (
              <p key={i} style={{ fontSize: 15, lineHeight: 1.85, color: 'var(--muted)', fontWeight: 300 }}>
                {text}
              </p>
            ))}
          </div>

          {/* Skill pills */}
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginTop: 40 }}>
            {[
              'Narrative Editing', 'Color Grading', 'Motion Graphics',
              'Sound Design', 'VFX Integration', 'Format Delivery',
              'Storyboarding', 'Offline Assembly',
            ].map((s) => (
              <span
                key={s}
                style={{
                  padding: '7px 14px',
                  border: '1px solid var(--border)',
                  borderRadius: 3,
                  fontSize: 11,
                  fontWeight: 500,
                  color: 'var(--muted)',
                  letterSpacing: '0.04em',
                }}
              >
                {s}
              </span>
            ))}
          </div>
        </div>

        {/* ── Right: Contact ── */}
        <div id="contact">
          <div style={S.overline}>
            <div style={S.overlineBar} />
            <span style={S.overlineText}>Get In Touch</span>
          </div>

          <h2
            className="font-display"
            style={{
              fontSize: 'clamp(30px, 3.2vw, 48px)',
              fontWeight: 900,
              lineHeight: 1.15,
              letterSpacing: '-0.02em',
              color: 'var(--text)',
              marginBottom: 40,
            }}
          >
            Let's create something<br />unforgettable.
          </h2>

          {/* Email block */}
          <EmailBlock copied={copied} onCopy={copy} />

          {/* Divider */}
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: 16,
              margin: '36px 0',
              color: 'var(--muted)',
              fontSize: 11,
              letterSpacing: '0.1em',
              textTransform: 'uppercase',
            }}
          >
            <div style={{ flex: 1, height: 1, background: 'var(--border)' }} />
            <span>Find me on</span>
            <div style={{ flex: 1, height: 1, background: 'var(--border)' }} />
          </div>

          {/* Socials */}
          <div style={{ display: 'flex', flexDirection: 'column' }}>
            {SOCIALS.map((s) => (
              <SocialRow key={s.label} icon={s.icon} label={s.label} handle={s.handle} />
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

function EmailBlock({ copied, onCopy }: { copied: boolean; onCopy: () => void }) {
  const [hov, setHov] = useState(false)
  return (
    <div
      onClick={onCopy}
      onMouseEnter={() => setHov(true)}
      onMouseLeave={() => setHov(false)}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => e.key === 'Enter' && onCopy()}
      aria-label="Copy email address"
      style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '20px 24px',
        background: hov ? 'var(--accent-dim)' : 'var(--card)',
        border: `1px solid ${hov ? 'var(--accent)' : 'var(--border)'}`,
        borderRadius: 6,
        cursor: 'pointer',
        transition: 'all 0.22s ease',
        outline: 'none',
      }}
    >
      <div>
        <div style={{ fontSize: 10, color: 'var(--muted)', letterSpacing: '0.14em', textTransform: 'uppercase', marginBottom: 5 }}>
          Email
        </div>
        <div style={{ fontSize: 16, fontWeight: 600, color: 'var(--text)', letterSpacing: '-0.01em' }}>
          hello@jeffmolina.com
        </div>
      </div>
      <div
        style={{
          fontSize: 11,
          fontWeight: 700,
          letterSpacing: '0.1em',
          textTransform: 'uppercase',
          color: copied ? '#22c55e' : 'var(--accent)',
          transition: 'color 0.2s ease',
        }}
      >
        {copied ? '✓ Copied' : 'Copy'}
      </div>
    </div>
  )
}

function SocialRow({ icon, label, handle }: { icon: React.ReactNode; label: string; handle: string }) {
  const [hov, setHov] = useState(false)
  return (
    <a
      href="#"
      onMouseEnter={() => setHov(true)}
      onMouseLeave={() => setHov(false)}
      style={{
        display: 'flex',
        alignItems: 'center',
        gap: 16,
        padding: '14px 0',
        borderBottom: '1px solid var(--border)',
        textDecoration: 'none',
        transition: 'all 0.2s ease',
      }}
    >
      <span
        style={{
          width: 36,
          height: 36,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          background: hov ? 'var(--accent-dim)' : 'var(--card)',
          border: `1px solid ${hov ? 'var(--accent)' : 'var(--border)'}`,
          borderRadius: 8,
          color: hov ? 'var(--accent)' : 'var(--muted)',
          transition: 'all 0.2s ease',
          flexShrink: 0,
        }}
      >
        {icon}
      </span>
      <div style={{ flex: 1 }}>
        <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--text)', lineHeight: 1.2 }}>{label}</div>
        <div style={{ fontSize: 11, color: 'var(--muted)', marginTop: 2 }}>{handle}</div>
      </div>
      <span
        style={{
          color: hov ? 'var(--accent)' : 'var(--border)',
          transition: 'color 0.2s ease',
        }}
      >
        <IconExternal />
      </span>
    </a>
  )
}

/* ─────────────────────────────────────────────────────────────────────────────
   FOOTER
───────────────────────────────────────────────────────────────────────────── */

function Footer() {
  return (
    <footer style={{ background: 'var(--bg2)', borderTop: '1px solid var(--border)' }}>
      <div
        className="footer-wrap"
        style={{ ...S.container, padding: '36px 48px' }}
      >
        <div
          className="footer-inner"
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            gap: 16,
            flexWrap: 'wrap',
          }}
        >
          <span className="font-display" style={{ fontSize: 18, fontWeight: 900, letterSpacing: '0.06em', color: 'var(--text)' }}>
            JMM<span style={{ color: 'var(--accent)' }}>.</span>
          </span>
          <span style={{ fontSize: 12, color: 'var(--muted)' }}>
            © 2024 Jeff Matthew Molina · All Rights Reserved
          </span>
          <span style={{ fontSize: 12, color: 'var(--muted)', letterSpacing: '0.04em' }}>
            Manila, PH · Available Globally
          </span>
        </div>
      </div>
    </footer>
  )
}

/* ─────────────────────────────────────────────────────────────────────────────
   FLOATING THEME WIDGET
───────────────────────────────────────────────────────────────────────────── */

function FloatingWidget({ dark, toggle }: { dark: boolean; toggle: () => void }) {
  const [hov, setHov] = useState(false)
  return (
    <div
      onMouseEnter={() => setHov(true)}
      onMouseLeave={() => setHov(false)}
      style={{
        position: 'fixed',
        bottom: 32,
        right: 32,
        zIndex: 300,
        display: 'flex',
        alignItems: 'center',
        gap: 10,
        background: dark ? 'rgba(26,26,26,0.92)' : 'rgba(255,255,255,0.92)',
        border: '1px solid var(--border)',
        backdropFilter: 'blur(12px)',
        WebkitBackdropFilter: 'blur(12px)',
        borderRadius: 100,
        padding: hov ? '10px 18px 10px 10px' : '10px',
        boxShadow: '0 8px 32px rgba(0,0,0,0.25)',
        cursor: 'pointer',
        transition: 'padding 0.3s ease, box-shadow 0.25s ease',
        overflow: 'hidden',
      }}
      onClick={toggle}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => e.key === 'Enter' && toggle()}
      aria-label="Toggle theme"
    >
      <div
        style={{
          width: 32,
          height: 32,
          borderRadius: '50%',
          background: dark ? '#FFFFFF' : '#0D0D0D',
          color: dark ? '#0D0D0D' : '#FFFFFF',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          flexShrink: 0,
          transition: 'all 0.3s ease',
        }}
      >
        {dark ? <IconSun /> : <IconMoon />}
      </div>
      <span
        style={{
          fontSize: 11,
          fontWeight: 700,
          letterSpacing: '0.1em',
          textTransform: 'uppercase',
          color: 'var(--text)',
          whiteSpace: 'nowrap',
          maxWidth: hov ? 120 : 0,
          opacity: hov ? 1 : 0,
          overflow: 'hidden',
          transition: 'max-width 0.3s ease, opacity 0.25s ease',
        }}
      >
        {dark ? 'Light Mode' : 'Dark Mode'}
      </span>
    </div>
  )
}

/* ─────────────────────────────────────────────────────────────────────────────
   ROOT
───────────────────────────────────────────────────────────────────────────── */

export default function App() {
  const [dark, setDark] = useState(true)
  const toggle = () => setDark((d) => !d)

  return (
    <div className={`grain-wrap ${dark ? 'dark' : ''}`}>
      <Nav dark={dark} toggle={toggle} />
      <main>
        <Hero />
        <Ticker />
        <Works />
        <AboutContact />
      </main>
      <Footer />
      <FloatingWidget dark={dark} toggle={toggle} />
    </div>
  )
}
